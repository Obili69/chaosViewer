'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
import { Zap, LayoutDashboard, Plus, ChevronDown, ChevronRight, LogOut, Users } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useNav } from './NavProvider'
import { AreaFormular } from '@/components/bereiche/AreaFormular'

interface AreaData {
  id: string
  name: string
  color: string
  projects: { id: string; name: string; color: string }[]
}

interface SidebarInnerProps {
  onLinkClick?: () => void
  currentUser?: { role: string }
}

function SidebarInner({ onLinkClick, currentUser }: SidebarInnerProps) {
  const pathname = usePathname()
  const [areas, setAreas] = useState<AreaData[]>([])
  const [ungrouped, setUngrouped] = useState<{ id: string; name: string; color: string }[]>([])
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({})
  const [areaFormOpen, setAreaFormOpen] = useState(false)

  useEffect(() => {
    fetch('/api/areas?withProjects=true')
      .then((r) => r.json())
      .then((data) => {
        setAreas(data.areas ?? [])
        setUngrouped(data.ungrouped ?? [])
      })
      .catch(() => {})
  }, [pathname])

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' })
    window.location.href = '/login'
  }

  const toggle = (id: string) => setCollapsed((prev) => ({ ...prev, [id]: !prev[id] }))

  const navLink = (href: string, label: string, icon: React.ReactNode, color?: string) => {
    const active = pathname === href || (href !== '/' && pathname.startsWith(href))
    return (
      <Link
        href={href}
        onClick={onLinkClick}
        className={cn(
          'flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm transition-colors group',
          active
            ? 'bg-accent/10 text-accent'
            : 'text-text-secondary hover:text-text-primary hover:bg-elevated'
        )}
      >
        {color ? (
          <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: color }} />
        ) : (
          <span className={cn('flex-shrink-0', active ? 'text-accent' : 'text-text-muted group-hover:text-text-secondary')}>
            {icon}
          </span>
        )}
        <span className="truncate">{label}</span>
      </Link>
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-4 py-5 flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center flex-shrink-0">
          <Zap className="w-4 h-4 text-accent" />
        </div>
        <span className="font-bold text-text-primary">ChaosTracker</span>
      </div>

      <nav className="flex-1 overflow-y-auto px-2 pb-4 space-y-1">
        {navLink('/', 'Übersicht', <LayoutDashboard className="w-4 h-4" />)}

        {/* Areas header */}
        <div className="flex items-center gap-1 px-3 pt-2 pb-0.5">
          <span className="flex-1 text-xs font-semibold text-text-muted uppercase tracking-wider">Bereiche</span>
          <button
            onClick={() => setAreaFormOpen(true)}
            className="p-0.5 rounded text-text-muted hover:text-accent hover:bg-accent/10 transition-colors"
            title="Neuer Bereich"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Areas */}
        {areas.map((area) => (
          <div key={area.id}>
            <button
              onClick={() => toggle(area.id)}
              className="w-full flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-text-muted hover:text-text-secondary uppercase tracking-wider transition-colors"
            >
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: area.color }} />
              <span className="flex-1 text-left truncate">{area.name}</span>
              {collapsed[area.id] ? <ChevronRight className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
            {!collapsed[area.id] && area.projects.map((p) => (
              <div key={p.id} className="ml-2">
                {navLink(`/projekte/${p.id}`, p.name, null, p.color)}
              </div>
            ))}
          </div>
        ))}

        {/* Ungrouped */}
        {ungrouped.length > 0 && (
          <div>
            <p className="px-3 py-1.5 text-xs font-semibold text-text-muted uppercase tracking-wider">
              Kein Bereich
            </p>
            {ungrouped.map((p) => (
              <div key={p.id} className="ml-2">
                {navLink(`/projekte/${p.id}`, p.name, null, p.color)}
              </div>
            ))}
          </div>
        )}
      </nav>

      {/* Bottom actions */}
      <div className="px-2 pb-4 space-y-1 border-t border-border pt-3">
        {navLink('/projekte/neu', 'Neues Projekt', <Plus className="w-4 h-4" />)}
        {currentUser?.role === 'ADMIN' && navLink('/einstellungen/benutzer', 'Benutzer', <Users className="w-4 h-4" />)}
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-text-secondary hover:text-red-400 hover:bg-red-500/10 transition-colors"
        >
          <LogOut className="w-4 h-4 flex-shrink-0" />
          <span>Abmelden</span>
        </button>
      </div>

      <AreaFormular
        open={areaFormOpen}
        onClose={() => setAreaFormOpen(false)}
        onSuccess={(area) => {
          setAreas((prev) => [...prev, { ...area, projects: [] }])
          setAreaFormOpen(false)
        }}
      />
    </div>
  )
}

export function Sidebar({ currentUser }: { currentUser?: { role: string } }) {
  return (
    <aside className="hidden md:flex fixed left-0 top-0 bottom-0 w-64 bg-surface border-r border-border flex-col z-40">
      <SidebarInner currentUser={currentUser} />
    </aside>
  )
}

export function MobileSidebar({ currentUser }: { currentUser?: { role: string } }) {
  const { sidebarOpen, setSidebarOpen } = useNav()

  if (!sidebarOpen) return null

  return (
    <div className="fixed inset-0 z-50 md:hidden">
      <div className="absolute inset-0 bg-black/60" onClick={() => setSidebarOpen(false)} />
      <aside className="absolute left-0 top-0 bottom-0 w-72 bg-surface border-r border-border">
        <SidebarInner onLinkClick={() => setSidebarOpen(false)} currentUser={currentUser} />
      </aside>
    </div>
  )
}
